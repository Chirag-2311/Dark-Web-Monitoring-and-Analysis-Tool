import * as THREE from "https://cdn.skypack.dev/three@0.129.0/build/three.module.js";
import { OrbitControls } from "https://cdn.skypack.dev/three@0.129.0/examples/jsm/controls/OrbitControls.js";
import { GLTFLoader } from "https://cdn.skypack.dev/three@0.129.0/examples/jsm/loaders/GLTFLoader.js";

// Create a Three.js Scene
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);

// Instantiate a loader for the .gltf file
const loader = new GLTFLoader();

// Load the file
loader.load(
    '../static/scene.gltf', // Assuming the model is in the public directory
    function (gltf) {
        const object = gltf.scene;
        scene.add(object);
    },
    function (xhr) {
        console.log((xhr.loaded / xhr.total * 100) + '% loaded');
    },
    function (error) {
        console.error('An error happened loading the GLTF model:', error);
    }
);

// Instantiate a new renderer and set its size
const renderer = new THREE.WebGLRenderer({ alpha: true });
renderer.setSize(window.innerWidth, window.innerHeight);
document.getElementById("three-container").appendChild(renderer.domElement);

// Add controls to the camera
const controls = new OrbitControls(camera, renderer.domElement);
controls.enableZoom = false; // Disable zoom
camera.position.z = 50; // Start further away for zoom effect

// Create a star field with increased star size
const starGeometry = new THREE.SphereGeometry(0.07, 6, 6); // Increased size for stars
const starMaterial = new THREE.MeshBasicMaterial({ color: 0xaaaaaa }); // Star color

// Function to create a star
function createStar(x, y, z) {
    const star = new THREE.Mesh(starGeometry, starMaterial);
    star.position.set(x, y, z);
    scene.add(star);
}

// Add multiple stars using a loop
for (let i = 0; i < 2000; i++) {
    // Random position for each star within a certain range
    const x = Math.random() * 200 - 100;
    const y = Math.random() * 200 - 100;
    const z = Math.random() * 200 - 100;
    createStar(x, y, z);
}

// Track mouse position
let mouseX = 0;
let mouseY = 0;

// Handle mouse movement
document.addEventListener('mousemove', (event) => {
    mouseX = (event.clientX / window.innerWidth) * 2 - 1;
    mouseY = -(event.clientY / window.innerHeight) * 2 + 1;
});

// Variables for the zoom effect
const targetCameraZ = 2; // Final camera position
const zoomSpeed = 0.03; // Speed of the zoom effect
let initialCameraZ = 50; // Initial camera position
let zoomingIn = true; // Whether the camera is zooming in or not

// Render the scene
function animate() {
    requestAnimationFrame(animate);

    // Rotate the scene around the Y axis for autorotation
    scene.rotation.y += 0.0025; // Adjust the rotation speed as needed

    // Zoom effect
    if (zoomingIn) {
        camera.position.z += (targetCameraZ - camera.position.z) * zoomSpeed;
        if (Math.abs(camera.position.z - targetCameraZ) < 0.1) {
            camera.position.z = targetCameraZ;
            zoomingIn = false; // Stop zooming in once the target is reached
        }
    }

    // Calculate the target position for the camera
    const targetX = mouseX * 5; // Adjust sensitivity as needed

    // Smoothly move the camera towards the target position with lag
    camera.position.x += (targetX - camera.position.x) * 0.05; // Adjust lag factor as needed

    controls.update();
    renderer.render(scene, camera);
}

// Handle window resize
window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
});

animate();
