const taglines = [
    "Safeguarding Your Digital Identity.",
    "Trust in Protection, Trust in Us.",
    "Ensuring Security in the Digital Age.",
    "Guardians of Cyber Space.",
    "Fortifying Your Cyber Defenses.",
    "Securing Your Digital Frontier."
];

let currentIndex = 0;
const taglineElement = document.querySelector('.tagline');

function updateTagline() {
    taglineElement.classList.remove('tagline-enter');
    taglineElement.style.opacity = 0; // Ensure previous tagline is hidden
    setTimeout(() => {
        taglineElement.textContent = taglines[currentIndex];
        taglineElement.classList.add('tagline-enter');
        taglineElement.style.opacity = 1;
        currentIndex = (currentIndex + 1) % taglines.length;
    }, 300); // Match the duration with the animation duration
}

// Initial tagline
taglineElement.textContent = taglines[currentIndex];
taglineElement.classList.add('tagline-enter');
currentIndex = (currentIndex + 1) % taglines.length;

setInterval(updateTagline, 3000); // Change tagline every 3 seconds

// Button click redirects
document.getElementById('default-button').addEventListener('click', function() {
    window.location.href = 'default.html'; // Replace with actual file path
});

document.getElementById('keyword-button').addEventListener('click', function() {
    window.location.href = 'keyword.html'; // Replace with actual file path
});

document.getElementById('crypto-button').addEventListener('click', function() {
    window.location.href = 'crypto.html'; // Replace with actual file path
});
